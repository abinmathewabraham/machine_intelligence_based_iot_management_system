package custominterfaces;

public interface ICallbacksForServerResponse {
    void responseFromServer(String responseJson);
}
