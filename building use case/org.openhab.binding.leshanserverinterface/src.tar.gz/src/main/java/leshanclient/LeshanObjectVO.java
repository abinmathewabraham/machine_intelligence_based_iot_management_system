package leshanclient;

public class LeshanObjectVO {
    int typeId;
    int instanceId;

    public LeshanObjectVO(int typeId, int instanceId) {
        super();
        this.typeId = typeId;
        this.instanceId = instanceId;
    }
}