package leshanservercommands;

public enum LeshanServerCommands {

    GET_CLIENTS,
    READ_RESOURCE,
    EXECUTE,
    WRITE

}
