package leshanservercommands;

public enum LeshanServerResponseStatus {
    CONTENT,
    NOT_FOUND
}
